
<!DOCTYPE html>
<html>
<head>



<!--Start Chat Script-->
<!--Start Chat Script-->
<!--Start Chat Script-->
<!--Start Chat Script-->
<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<!--End Chat Script-->
<!--End Chat Script-->
<!--End Chat Script-->
<!--End Chat Script-->



        <meta charset="utf-8">
	<title>Members Area</title>
        <META NAME="ROBOTS" CONTENT="NOINDEX, NOFOLLOW">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<link rel="stylesheet" href="normalize.css">
	<link rel="stylesheet" href="style.css">
	
	
	
	
<!--Pull Down for Menu Bar-->	
<!--Pull Down for Menu Bar-->	
<!--Pull Down for Menu Bar-->		
<!--Pull Down for Menu Bar-->	
	  <link href='http://fonts.googleapis.com/css?family=PT+Sans:400,700' rel='stylesheet' type='text/css'>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<!--End Pull Down for Menu Bar-->	
<!--End Pull Down for Menu Bar-->	
<!--End Pull Down for Menu Bar-->	
<!--End Pull Down for Menu Bar-->	


<!--Nav Bar Fucntions-->
<!--Nav Bar Fucntions-->
<!--Nav Bar Fucntions-->
<!--Nav Bar Fucntions-->
	<script>
		$(function() {
			var pull 		= $('#pull');
				menu 		= $('nav ul');
				menuHeight	= menu.height();

			$(pull).on('click', function(e) {
				e.preventDefault();
				menu.slideToggle();
			});

			$(window).resize(function(){
        		var w = $(window).width();
        		if(w > 320 && menu.is(':hidden')) {
        			menu.removeAttr('style');
        		}
    		});
		});
		
		
		<!--SCRIPTS!!!!!!!!------------------->
		<!--SCRIPTS!!!!!!!!------------------->
		<!--SCRIPTS!!!!!!!!------------------->
		<!--SCRIPTS!!!!!!!!------------------->
		
	</script>
<!-- End Nav Bar Fucntions-->
<!-- End Nav Bar Fucntions-->
<!-- End Nav Bar Fucntions-->
<!-- End Nav Bar Fucntions-->



<!-- disable view code-->
<!-- disable view code-->
<!-- disable view code-->
<!-- disable view code--------------------------------> 
    <script type="text/javascript">/*
document.onkeydown = function (cc) {
if(cc.which == 85){
return false;
}
if(cc.which == 80){
return false;
}
<!--end disable view code-->
<!--end disable view code-->
<!--end disable view code-->
<!--end disable view code-->



<!-- pre load image?-->*/
}
function MM_preloadImages() { //v3.0
  var d=document; if(d.images){ if(!d.MM_p) d.MM_p=new Array();
    var i,j=d.MM_p.length,a=MM_preloadImages.arguments; for(i=0; i<a.length; i++)
    if (a[i].indexOf("#")!=0){ d.MM_p[j]=new Image; d.MM_p[j++].src=a[i];}}
}
<!--end pre loa image?-->




</script>
		<!--ENd SCRIPTS!!!!!!!!------------------->
		<!--ENd SCRIPTS!!!!!!!!------------------->
		<!--ENd SCRIPTS!!!!!!!!------------------->
		<!--ENd SCRIPTS!!!!!!!!------------------->
    



</head>




    <!---------------BODY UNSELECTABLE------------------------------------------------->
    <!---------------BODY UNSELECTABLE------------------------------------------------->
<body class="unselectable" oncontextmenu="return false;">
    <!---------------BODY UNSELECTABLE------------------------------------------------->
    <!---------------BODY UNSELECTABLE------------------------------------------------->












<!--contact us code-->
<div class="cardNew" id="creditNewForm" style="display: none;">
		<div class="cardNew-title " id="contactUsTitle" >
				<div class="imageNewForm" >
					<svg fill="none" height="30" viewBox="0 0 24 24" width="30" xmlns="http://www.w3.org/2000/svg"><path d="M22 12C22 10.6868 21.7413 9.38647 21.2388 8.1731C20.7362 6.95996 19.9997 5.85742 19.0711 4.92896C18.1425 4.00024 17.0401 3.26367 15.8268 2.76123C14.6136 2.25854 13.3132 2 12 2V4C13.0506 4 14.0909 4.20703 15.0615 4.60889C16.0321 5.01099 16.914 5.60034 17.6569 6.34326C18.3997 7.08594 18.989 7.96802 19.391 8.93848C19.7931 9.90918 20 10.9495 20 12H22Z" fill="currentColor"/><path d="M2 10V5C2 4.44775 2.44772 4 3 4H8C8.55228 4 9 4.44775 9 5V9C9 9.55225 8.55228 10 8 10H6C6 14.4182 9.58173 18 14 18V16C14 15.4478 14.4477 15 15 15H19C19.5523 15 20 15.4478 20 16V21C20 21.5522 19.5523 22 19 22H14C7.37259 22 2 16.6274 2 10Z" fill="currentColor"/><path d="M17.5433 9.70386C17.8448 10.4319 18 11.2122 18 12H16.2C16.2 11.4485 16.0914 10.9023 15.8803 10.3928C15.6692 9.88306 15.3599 9.42017 14.9698 9.03027C14.5798 8.64014 14.1169 8.33081 13.6073 8.11963C13.0977 7.90869 12.5515 7.80005 12 7.80005V6C12.7879 6 13.5681 6.15527 14.2961 6.45679C15.024 6.7583 15.6855 7.2002 16.2426 7.75732C16.7998 8.31445 17.2418 8.97583 17.5433 9.70386Z" fill="currentColor"/></svg>
					<!-- <img src="contact-30.png" > -->
				</div>
	    	<div class="Text_headerNewForm" >	
	    		<div class="contact_us_headNewForm">Contact Us</div>
	    	</div>
	    	<div class="imageArrowNewForm">
					<span class="checkImageNewForm">
						<svg width="30px" id="chevronsArrowForm" class="chevron_downNewForm" onclick="chevronsArrowFormFunc(this)" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><style>.cls-1{fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:2px;}</style></defs><title/><g id="chevron-bottom"><line class="cls-1" x1="16" x2="7" y1="20.5" y2="11.5"/><line class="cls-1" x1="25" x2="16" y1="11.5" y2="20.5"/></g></svg>
						<!-- <img src="chevron_downNewForm.png" width="8" > -->
					</span>
				</div>
		</div>
		<form id="creditNewForm_form" method="POST" name="creditNewForm_form" action="?" onsubmit="event.preventDefault();">
			<div class="form-rowNewForm" id="Contact_Name_fieldNewForm">
				<div class="form-groupNewForm">
					Name
					<input type="text" name="first_name" id="form_fname" class="form-controlNewForm error_message" >
					<!--- <span class="error_form" id="fname_error_message"></span> --->
				</div>
				<div class="form-groupNewForm" id="Contact_Email_field" >
					Email Address
					<input type="email" name="email" id="form_email" class="form-controlNewForm" type="email" >
					<!--- <span class="error_form" id="email_error_message"></span> --->
				</div>
				<div class="form-groupNewForm" id="Contact_Message_field" >
					Message
					<textarea class="form-controlNewForm" id="form_message" rows="3"></textarea>
					<!-- <input type="tex" name="password" id="form_password" class="form-controlNewForm" > -->
					<!--- <span class="error_form" id="password_error_message"></span> --->
				</div>

				<div class="form-groupNewForm text-center">
					<!-- <img src="image-name" width="300px" height="100px"> -->
					<button class="btn btn-primary contact-submit-btn" type="submit" >Send</button>
				</div>
			</div>
		</form>
</div>
<div class="contactOpenBtn">
	<img src="bubble.svg" width="100px" height="100px">
</div>


<!--contact us code-->










<!- NAV BAR----->
<!- NAV BAR----->
<!- NAV BAR----->
<!- NAV BAR----->	
    <nav class="clearfix">
		<ul class="clearfix">
			<li><a href="https://verifiedmemberaccess.com/1StartHereMobile.php">(1.) Start Here </a></li>
			<li><a href="https://verifiedmemberaccess.com/2WorkoutsMobile.php" > (2.) Workouts  </a></li>
			<li><a href="https://verifiedmemberaccess.com/3HelpAndBonusContent.php"> (3.) Problems  </a></li>
		
		</ul>
	<a href="#" id="pull">Menu</a></a></nav>
<!-END NAV BAR----->
<!-END NAV BAR----->
<!-END NAV BAR----->
<!-END NAV BAR----->
    
    
    
    


<div align="center" class="container80"> 
  <p>&nbsp;</p>
  <p> 
  
  <!-- GOOGLE TRANSLATE -->
  <!-- GOOGLE TRANSLATE -->
  <!-- GOOGLE TRANSLATE -->
  <!-- GOOGLE TRANSLATE -->
  
          <div id="google_translate_element" ></div>

<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'en', includedLanguages: 'af,sq,ar,az,eu,bn,be,bg,ca,zh-CN,hr,cs,da,nl,en,eo,et,tl,fi,fr,gl,ka,de,el,gu,ht,iw,hi,hu,is,id,ga,it,ja,kn,ko,la,lv,lt,mk,ms,mt,no,fa,pl,pt,ro,ru,sr,sk,sl,es,sw,sv,ta,te,th,tr,uk,ur,vi,cy,yi', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
}
</script>
<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<style>

/* Audio CSS*/
/* Audio CSS*/
/* Audio CSS*/
/* Audio CSS
iframe {
width: 600px;
height: 20px;
}
/* Audio CSS*/
/* Audio CSS*/
/* Audio CSS*/
/* Audio CSS*/

div#google_translate_element div.goog-te-gadget-simple{background-color:green;}
    div#google_translate_element div.goog-te-gadget-simple a.goog-te-menu-value span{color:yellow}
    
    div#google_translate_element div.goog-te-gadget-simple a.goog-te-menu-value span:hover{color:#ffffff}


   
  /*<!-- size of google translation bar -->*/
  /*<!-- size of google translation bar -->*/
  /*<!-- size of google translation bar -->*/
  /*<!-- size of google translation bar -->*/
  
  
  

  
  
</style>

    </p></div>
    
    
  <!-- END GOOGLE TRANSLATE -->
  <!-- END GOOGLE TRANSLATE -->
  <!-- END GOOGLE TRANSLATE -->
  <!-- END GOOGLE TRANSLATE -->
    
    
    
    
    
  <!-- BODY -->
  <!-- BODY -->
  <!-- BODY -->
  <!-- BODY -->
    
    
   <div align="center" class="container80">
   </p>
<p align="center"><i>Area Ver 23.81</i> <br><br></P>



<p align="center">


  <iframe src="https://player.vimeo.com/video/349947839" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
  









  <p>&nbsp;</p>
  <p align="center">&nbsp;</p>
<p align="left">If you see an orange &quot;Menu&quot; bar, click it to access the Nav Bar.</p>
<p align="left">In the Nav Bar start with &quot;<strong>(1.)</strong> <strong>Start Here</strong>&quot; in the upper left, inside you will learn everything you need about the five grip types, the use of lubes, warming up, and making your gains permanent.</p>
<p align="left">&nbsp;</p>
<p align="left">Then you can enter &quot;<strong>(2.) Workouts</strong>&quot; to see the video lessons and pre made workouts.</p>
<p align="left">&nbsp;</p>
<p align="left">If you have trouble see &quot;<strong>(3.) problems</strong>&quot; before you contact us, the hyper link &quot;troubleshooting&quot; will cover most all issues you may have.</p>
<p align="left">&nbsp;</p>
<p align="left"><strong>NOTICE:</strong> the URL does not say &quot;penisprofessor&quot; to protect your privacy, bookmark this page if you do not want thepenisprofessor.com or penisprofessor.com in your browser history, and do not let your browser save your password if you do not want others to see what you are doing online with our site.</p>
<p align="center">&nbsp;</p>
  <p align="center">&nbsp;</p>

	  <!-- VIDEO/AUDIO -->
	  <!-- VIDEO/AUDIO -->
	  <!-- VIDEO/AUDIO -->
	  <!-- VIDEO/AUDIO -->








     <!-- END VIDEO/AUDIO -->
	  <!-- END VIDEO/AUDIO -->
	  <!-- END VIDEO/AUDIO -->
	  <!-- END VIDEO/AUDIO -->

<p align="left">
UPDATES: <br>
To further protect your privacy our members area is now hosted in "verifiedmemberaccess.com", a secure https site built to make it so no one can guess what you are working on if you forget to delete your history.
<br>
<br> Let us know if any urls look sex related so we can change them.
<br>
<br>
<strong>ADDED</strong><br>
<strong>60 + Video demonstrations</strong> <br><br>
 New content covers grip types, cementing, edging, erection levels, foreskin restoration. the loose skin fix for uncircumcised men, lubrication, measuring your penis, length exercises, girth exercises, stretches, pc exercises, and testicle enlargement. <br>
<br>
<strong>Real Penis and Prop based</strong> video content avilabe.<br><br>
<strong>Improved user interface</strong> (let us know if you have further sugesstions)

<br>
<br>

We apologize for the delay but 3 years of research finished all at the same time, and then covid hit. But the new members area update is now here.<br><br>
- The Professor


  <!-- END BODY -->
  <!-- END BODY -->
  <!-- END BODY -->
  <!-- END BODY -->


</div>
</div>
</body>



<!---Contqact us script-->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js" ></script>
<script src="https://smtpjs.com/v3/smtp.js"></script> 
<script type="text/javascript">
	
$.validator.addMethod("lettersonly", function(value, element) {
    return this.optional(element) || /^[a-zA-Z\s ]*$/.test(value);
}, "Should contain only characters.");
$.validator.addMethod("numeric", function(value, element) {
    return this.optional(element) || /^[0-9]*$/.test(value);
}, "Should contain only numbers.");
$.validator.addMethod("email", function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
}, "Please enter a valid email address.");
$.validator.addMethod("minimum_ammount", function(value, element) {
    return this.optional(element) || /^[5-9]*$/.test(value);
},);
var submitForm = 0;

$('#creditNewForm_form').validate({  
  rules:{
    first_name:{
      required:true,
      lettersonly: true
    },
    email:{
      required:true,
      email:true
    },
  },
  messages:{
    first_name:{
      required:"Please enter your name",
    },
    email:{
      required:"Please enter email",
    },

  },

    submitHandler:function(form){
    	console.log('submitform');
    	submitForm = 1;
    	contact_submit(submitForm);
    }
});
$(".contactOpenBtn").on('click',function(){
		$("#creditNewForm").fadeIn(200);
		$(".contactOpenBtn").fadeOut(200);
});
function chevronsArrowFormFunc(key){
	var image_name = $(key).attr('class');
	if (image_name == 'chevron_downNewForm') {
		$(".contactOpenBtn").fadeIn(250);
		$("#creditNewForm").fadeOut(250);
	}
}
function contact_submit(submitForm){
	if(submitForm == 1){
		console.log('esle');
		var send = false;
		var getname = $("#creditNewForm_form #form_fname").val();
		var getemail = $("#creditNewForm_form #form_email").val();
		var getmessage = $("#creditNewForm_form #form_message").val();
		if (getmessage.trim() == '') {
			getmessage = 'Empty';
		}

		var myFormData = new FormData();

  	myFormData.append("name", getname);
  	myFormData.append("email", getemail);
  	myFormData.append("message", getmessage);

		$.ajax({
			url: "faq_ajax.php",
			type: "post",
			data:myFormData,
			success: function (data) {
				$("#creditNewForm_form").trigger('reset');
				$(".contactOpenBtn").fadeIn(250);
				$("#creditNewForm").fadeOut(250);
      },
			cache: false,
      contentType: false,
      processData: false,
		});
	}
}
</script>

<!--end contact us script-->


</html>