<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Member Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #fafafa/*D84315*/;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        #slform_10 {
            background-color: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 300px;
        }
        .login-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .login-header h3 {
            margin: 0;
            color: #333;
            font-size: 14px;
        }
        .login-header h2 {
            margin: 5px 0;
            color: #333;
        }
        h2 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .sltextfield_10 {
            margin-bottom: 15px;
        }
        .sltextfield_10 label {
            display: none;
        }
        .sltextfield_10 input[type="text"], .sltextfield_10 input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 16px;
            background-color: #f0f0f0; /* Light gray background for input fields */
        }
        #myButton_10 {
            width: 100%;
            padding: 10px;
            background-color: #2196F3;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            margin-bottom: 10px;
        }
        #myButton_10:hover {
            background-color: #1976D2;
        }
        #slforgot_10 {
            display: block;
            text-align: center;
            color: #FF0000;
            text-decoration: none;
            margin-bottom: 10px;
        }
        #slformmsg_10 {
            text-align: center;
            color: #FF0000;
            margin-top: 10px;
        }
        #slfakenamediv_10 {
            display: none;
        }
    </style>
    <script type="text/javascript"><!--
    function slvalidateform_10(form)
    {
      var loginmessage=document.getElementById('slformmsg_10');
      loginmessage.innerHTML='';
      var username=document.getElementById('slfieldinput_10_username');
      if (sltrim_10(username.value)=="")
      {
        loginmessage.innerHTML='Please enter your username';
        username.focus();
        return(false);
      }
      var password=document.getElementById('slfieldinput_10_password');
      if (sltrim_10(password.value)=="")
      {
        loginmessage.innerHTML='Please enter your password';
        password.focus();
        return(false);
      }  loginmessage.innerHTML='';
      var slajaxavailable=false;
      if ((window.XMLHttpRequest) && (typeof JSON === "object"))
        slajaxavailable=true;
      if (slajaxavailable)
      {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function()
        {
          if (xhttp.readyState == 4 && xhttp.status == 200)
          {
            // Handle callback
            document.getElementById('myButton_10').disabled=false;
            document.getElementById('slspinner_10').style['display']="none";
            var data = JSON.parse(xhttp.responseText);
            if (data.success)
            {
              window.location=data.redirect;
              return(false);
            }
            else  
            {  
              if (!Date.now) {
                Date.now = function() { return new Date().getTime(); };
              };
              timg=document.querySelectorAll("img.slturingimg");
              for (i = 0; i < timg.length; i++)
                timg[i].src = "/slpw/turingimage.php?t="+Math.floor(Date.now());
              tinp=document.getElementsByName("turing");
              for (i = 0; i < tinp.length; i++)
                tinp[i].value = "";
              loginmessage.innerHTML = data.message;
              return(false);
            }
          }
        };
        // Serialize form
        var formData=sl_serialize(form);
        formData+="&slajaxform=1";
        var slfrmact=form.action;
        if (slfrmact=="")
          slfrmact=window.location.href;
        document.getElementById('myButton_10').disabled=true;
        document.getElementById('slspinner_10').style['display']="block";    
        xhttp.open("POST", slfrmact, true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send(formData);
        return(false);
      }
      return(true);
    }
    
    function forgotpw_10()
    {
      var loginmessage=document.getElementById('slformmsg_10');
      loginmessage.innerHTML='';
      var username=document.getElementById('slfieldinput_10_username');
      if (sltrim_10(username.value)=="")
      {
         loginmessage.innerHTML='Please enter your username or email address';
        username.focus();
        return(false);
      }
      var forgotpassword=document.getElementById('forgotpassword_10');	
      forgotpassword.value="forgotten-it";
      var form=document.getElementById('siteloklogin_10');
      loginmessage.innerHTML='';
      var slajaxavailable=false;
      if ((window.XMLHttpRequest) && (typeof JSON === "object"))
        slajaxavailable=true;
      if (slajaxavailable)
      {
        var xhttp = new XMLHttpRequest();
        xhttp.onreadystatechange = function()
        {
          if (xhttp.readyState == 4 && xhttp.status == 200)
          {
            // Handle callback
            document.getElementById('myButton_10').disabled=false;
            document.getElementById('slspinner_10').style['display']="none";
            var data = JSON.parse(xhttp.responseText);
            if (data.success)
            {
              forgotpassword.value="";          
              window.location=data.redirect;
              return(false);
            }
            else  
            {  
              if (!Date.now) {
                Date.now = function() { return new Date().getTime(); };
              };
              timg=document.querySelectorAll("img.slturingimg");
              for (i = 0; i < timg.length; i++)
                timg[i].src = "/slpw/turingimage.php?t="+Math.floor(Date.now());
              tinp=document.getElementsByName("turing");
              for (i = 0; i < tinp.length; i++)
                tinp[i].value = "";
              forgotpassword.value="";
              loginmessage.innerHTML = data.message;
              return(false);
            }
          }
        };
        // Serialize form
        var formData=sl_serialize(form);
        formData+="&slajaxform=1";
        var slfrmact=form.action;
        if (slfrmact=="")
          slfrmact=window.location.href;
        document.getElementById('myButton_10').disabled=true;
        document.getElementById('slspinner_10').style['display']="block";    
        xhttp.open("POST", slfrmact, true);
        xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        xhttp.send(formData);
        return(false);
      }
      form.submit(); 
      return(true);
    }
    
    function sltrim_10(x)
    {
        return x.replace(/^\s+|\s+$/gm,'');
    }
    
    function viewpass_10(id)
    {
      var x = document.getElementById(id);
      if (x.type === "password") {
        x.type = "text";
      } else {
        x.type = "password";
      }
    }
      function sl_serialize(form)
    {
     if (!form || form.nodeName !== "FORM") {
       return;
     }
     var i, j, q = [];
     for (i = form.elements.length - 1; i >= 0; i = i - 1) {
       if (form.elements[i].name === "") {
         continue;
       }
       switch (form.elements[i].nodeName) {
       case 'INPUT':
         switch (form.elements[i].type) {
         case 'text':
         case 'email':
         case 'number':
         case 'hidden':
         case 'password':
         case 'button':
         case 'reset':
         case 'submit':
           q.push(form.elements[i].name + "=" + encodeURIComponent(form.elements[i].value));
           break;
         case 'checkbox':
         case 'radio':
           if (form.elements[i].checked) {
             q.push(form.elements[i].name + "=" + encodeURIComponent(form.elements[i].value));
           }           
           break;
         case 'file':
           break;
         }
         break;       
       case 'TEXTAREA':
         q.push(form.elements[i].name + "=" + encodeURIComponent(form.elements[i].value));
         break;
       case 'SELECT':
         switch (form.elements[i].type) {
         case 'select-one':
           q.push(form.elements[i].name + "=" + encodeURIComponent(form.elements[i].value));
           break;
         case 'select-multiple':
           for (j = form.elements[i].options.length - 1; j >= 0; j = j - 1) {
             if (form.elements[i].options[j].selected) {
               q.push(form.elements[i].name + "=" + encodeURIComponent(form.elements[i].options[j].value));
             }
           }
           break;
         }
         break;
       case 'BUTTON':
         switch (form.elements[i].type) {
         case 'reset':
         case 'submit':
         case 'button':
           q.push(form.elements[i].name + "=" + encodeURIComponent(form.elements[i].value));
           break;
         }
         break;
       }
     }
     return q.join("&");
    }
    //--></script>
    </head>
<body>
    <div id="slform_10">
        <div class="login-header">
            <h3>VerifiedMembersAccess.com for</h3>
            <h2>"The Professor"</h2>
        </div>
        <h2>Member Login</h2>
        <form action="/logincode.php?redirect=/members.php" method="post" id="siteloklogin_10" onSubmit="return slvalidateform_10(this)">
            <input type="hidden" id="loginformused_10" name="loginformused" value="1">
            <input type="hidden" id="forgotpassword_10" name="forgotpassword" value="">
            <div class="sltextfield_10">
                <label for="slfieldinput_10_username">Username</label>
                <input type="text" class="slinput" name="username" id="slfieldinput_10_username" placeholder="User Name" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="100" value="">
            </div>
            <div class="sltextfield_10">
                <label for="slfieldinput_10_password">Password</label>
                <input type="password" class="slinput" name="password" id="slfieldinput_10_password" placeholder="Password" autocorrect="off" autocapitalize="off" spellcheck="off" maxlength="50" value="">            </div>
            <div class="sltextfield_10" id="slfakenamediv_10">
                <label for="slfakename_10">There is no need to fill in this field</label>
                <input type="text" class="slinput" name="fakename" id="slfakename_10" placeholder="fakename" autocomplete="off">
            </div>
            <button class="slbutton" id="myButton_10" type="submit">LOGIN<div id="slspinner_10"></div></button>
            <a id="slforgot_10" href="#" title="Please enter your username or email address">Forgot Password?</a>
            <div id="slformmsg_10" class="slformmsg_10" aria-live="polite"></div>
        </form>
 
    <h>Your Username is the Email you gave us when you bought our product, If you did not receive username/password email at sign up (or forgot it). Enter that email and click "forgot Password".<br><br> Then check your email.</h>
 
 
    </div>
    
    
    
    
    <script type="text/javascript"><!--
    //var el = document.getElementById('slforgot_10');
    //el.onclick = forgotpw_10;
    if (slforgot_10.addEventListener) {  // all browsers except IE before version 9
      slforgot_10.addEventListener("click", forgotpw_10, false);
    } else {
      if (slforgot_10.attachEvent) {   // IE before version 9
        slforgot_10.attachEvent("click", forgotpw_10);
      }
    }
    timg=document.querySelectorAll("img.slturingimg");
    for (i = 0; i < timg.length; i++)
      timg[i].src = "/slpw/turingimage.php?t="+Math.floor(Date.now());
    //--></script>
</body>
</html>
