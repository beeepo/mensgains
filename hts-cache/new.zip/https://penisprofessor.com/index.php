<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

            <meta name="author" content="PenisProfessor">
            <meta name="viewport" content="width=device-width; initial-scale=1; maximum-scale=1">
            <meta name="description" content="Enjoy this quick look at the most effective penis enlargement system on the net, with out ANY exspensive tools you too can grow INCHES fast try The PenisProfessor.com today!">





<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>



            

<meta name="keywords"
 content="
 Penis Professor.com, 
 The Penis Professor.com, 
 The Penis Professor,
 ThePenisProfessor,
 ThePenisProfessor.com,
 Penis, 
 Professor, 
 Proffesor, 
 Proffessor, 
 Penis Professor, 
 ThePenisProffesor,
 The Penis, 
 Penisprofessor.com, 
 Penis Professor.com,
 PenisProfessor">


<title>The Penis Professor A Quick Look</title>



<!-- SCRIPTS-->
<!-- SCRIPTS-->
<!-- SCRIPTS-->
<!-- SCRIPTS-->

<!-- Nav Bar css-->
<!-- Nav Bar css-->
<!-- Nav Bar css-->
<!-- Nav Bar css-->
<style>
/*<!--meta name="google-site-verification" content="bUsQ4QMnoKA3OcLqFskl-HhRbTVnUTsCRf0vm8ExAL0" /-->*/

	<style type="text/css">
	/*	@media screen and (max-width: 600px) {
			#creditNewForm {
				width: auto ;
			}
		}

		@media screen and (min-width: 601px) {
			#creditNewForm {
				width: 360px ;
			}
		}*/
	
		input.error{
		    border-bottom: 2px solid #33373d;
		}
		
		#creditNewForm{
				color: #fff !important; /* name/email/message color - words over the input feild*/
		    position: absolute;
		    bottom: 20px;
		    left: 20px;
		    margin-left: 20px;
		    margin-bottom: 20px;
		    font-family: system-ui !important;
		    height: auto;
		    position: fixed;
		    background-color: #333 !important; /*02377dbg of contact us card*/
		    border: 1px solid #f2f3f7 !important;
		    box-sizing: border-box !important;
		    box-shadow: 0px 8px 20px rgb(0 0 0 / 20%) !important;
		    border-radius: 16px 16px 16px 16px !important;
		    z-index: 99999999 !important;
            max-width: 500px !important;
            min-width: 300px !important;
		    width: 50% !important;
		}
		.contactOpenBtn{
		    margin-left: 20px;
		    margin-bottom: 20px;
		    /*position: fixed;*/

		    cursor: pointer;
		    display: flex;
		    justify-content: center;
		    align-items: center;
		    position: fixed;
		    bottom: 20px;
		    left: 20px;
		    z-index: 2147483000;
		    width: 60px;
		    height: 60px;
		   /* border: none;
		    border-radius: 50%;
		    background: #1fb141;
		    box-shadow: 0 1px 6px 0 rgb(0 0 0 / 6%), 0 2px 32px 0 rgb(0 0 0 / 16%);*/
		}
		.contact_us_headNewForm{    /*Contact Us Text Color*/
		    color: #fff !important;
/**/		    font-size: 18px !important;
		    font-weight: 700 !important;
		    font-family: system-ui !important;
		    letter-spacing: 0 !important;
		    margin-bottom: 0px !important;
		}
		.contact_form_head{
		    line-height: 1.2;
		    font-size: small;
		    color: #959ca6 !important;
		    font-size: 12px !important;
		    font-weight: 400 !important;
		}
		.imageNewForm{
		        display: inline-flex;
		    width: fit-content;
		}
		.imageArrowNewForm{
		    display: inline-flex;
		    float: right;
		    margin-right: 9px;
		    margin-top: 5px;
		}
		.Text_headerNewForm{
		    padding-left: 5px;
		    display: inline-block;
		}
		.form-controlNewForm:focus{
		    -webkit-box-shadow: none;
		    box-shadow: none;
		    color: #495057; /*color of tex in input when you type*/
		    background-color: #fff; /*bgcolor of selected input when you type*/
		    border-color: black;
		    outline: 0;
		}
		.submit-btn{

		}
		#place-input {
		  position: fixed ;
		  background-color: #fff;
		  font-family: Roboto;
		  font-size: 15px;
		  font-weight: 300;
		  margin-left: 0 !important;
		  padding: 0 11px 0 13px;
		  text-overflow: ellipsis;
		  width: 250px;  /*MAYBE----------------------------------------------------*/
		  height: 30px;
		}
		.gmnoprint{
		    margin-top: 60px !important;
		}
		#place-input:focus {
		  border-color: #4d90fe;
		}
		.main_row_payement{

		    height: 500px !important;
		    overflow: hidden;
		    justify-content: center;

		}
		.cardNew{
		    background-color: #FCFCFC !important;
		    border: 1px solid #eee !important ;
		    padding: 15px;
		    border-radius: 10px !important;
		    /*overflow: auto;*/
		    height: 430px;
		    overflow-y: auto;
		}
		.mapArea{
		    height: 400px;
		}

		.content-box-large {
		    background-color: #FCFCFC !important;
		    margin-bottom: 30px;
		    background: #fff;
		    border-radius: 10px;
		    border-left: 1px solid #eee;
		    border-top: 1px solid #eee;
		    border-right: 2px solid #eee;
		    border-bottom: 2px solid #eee;
		    overflow: hidden;
		    height: 500px;
		    overflow-y: scroll;
		}
		.payement_info{
		    text-align: ;
		}
		.main_heading{
		    color:#01A4D0;
		    font-size: 1.75rem;
		    text-align: center;
		}
		.sub_heading{
		    font-size: 1.15rem;
		}

		.panel-heading {
		    padding: 5px;
		    border-bottom: 1px solid transparent;
		    border-top-right-radius: 3px;
		    border-top-left-radius: 3px;
		}

		.panel-heading>.panel-title{
		    padding-left: 15px;
		}

		.panel-body {
		    clear: both;
		        padding: 5px 15px;
		}


		.control-label {
		    font-size: 12px;
		}

		.label{
		    font-size: 11px;
		}

		.agreement_label{
		    margin: 0;
		}

		.form-groupNewForm{
				
		    padding-right: 5px;
    		padding-left: 5px;
		    font-size: 14px !important;
		    font-weight: 500 !important;
		    margin-bottom: 1rem!important;
				position: relative;
		    width: 100%;
		    min-height: 1px;

		}
		.form-rowNewForm{
		  display: flex;
	    -ms-flex-wrap: wrap;
	    flex-wrap: wrap;
	    margin-right: -5px;
	    margin-left: -5px;
		}
		.control-label{
		    font-size: 1rem;
		}

		.exp{
		    display: inline-flex;
		}

		.center-block {
		    display: block;
		    margin-right: auto;
		    margin-left: auto;
		}

		.error_form{
		  color: red;
		}
		#map {
		    width: 100%;
		    height: 100%;
		}
		.mapArea{
		    padding: 0px;
		    background-color: #ecefdc;
		}
		.contact-submit-btn {
				width: 100%;
		    color: black;
		    background-color: #ffcc33;/* send button no hover*/
		    border-color: #ffcc33; /*send button no hover*/
		    display: inline-block;
		    font-weight: 400;
		    text-align: center;
		    white-space: nowrap;
		    vertical-align: middle;
		    -webkit-user-select: none;
		    -moz-user-select: none;
		    -ms-user-select: none;
		    user-select: none;
		    border: 1px solid transparent;
		    padding: 0.375rem 0.75rem;
		    font-size: 1rem;
		    line-height: 1.5;
		    border-radius: 0.25rem;
		    transition: color .15s ease-in-out,background-color .15s ease-in-out,border-color .15s ease-in-out,box-shadow .15s ease-in-out;
		}
		.contact-submit-btn:hover {
		    color: black;
		    background-color: #dfb22d; /*send button hover*//*send button hover*/
		    border-color: #ffcc33;/*send button hover*//*send button hover*/
		}
		.contact-submit-btn:not(:disabled):not(.disabled):active{
		    color: black;
		    background-color: #dfb22d;/*send button hover*//*send button hover*/
		    border-color: #ffcc33;/*send button hover*//*send button hover*/
		}
		.contact-submit-btn:not(:disabled):not(.disabled):active:focus{
		    color: black !important;
		    background-color:#61aa8b !important;/*send button hover*//*send button hover*/
		    border-color: #ffcc33 !important;/*send button hover*//*send button hover*/
		    box-shadow: none;
		}
		#chevronsArrowForm{
		    cursor: pointer;
		    border-radius: 10px;
		    border: hidden;
		}
		#chevronsArrowForm:not(:disabled):not(.disabled):active{
		    background-color: #c6cfdb;
		}
		.contact-submit-btn:focus{
			background-color:#61aa8b !important;
			 color: white !important;
		}
		.contact-submit-btn:not(:disabled):not(.disabled) {
		    cursor: pointer;
		}
		#creditNewForm_form{
			border: hidden;
		}

	label.error{
	    color: yellow;
		}

		.form-controlNewForm{ /*------------------------------------------------------------------*/
    	
			display: block;
             width: 98.7% !important; /*width of name.email.message inputs*/
	    font-size: 1rem;
	    line-height: 1.5;
	    color: #495057 /*unknown color*/;
	    background-color: #fff; /*bg of input*/
	    background-clip: padding-box;
	    border: 1px solid #ced4da;
	    border-radius: 0.25rem; /*rounds edges of input feilds*/
	    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
		}
		.imageNewForm svg{
			color: fff; /*phone color---------------------------------------------------------------------------*/
		}
		.digitalSeaBtn{
			color: white;
			text-decoration: none !important;

		}
		.digitalSeaBtn:hover{
			color: white;
		}
		.cardNew-title{
			scale: 95%; /*size of contact us words*/
			margin-bottom: 0.75rem;
		}
		/*
		@media screen and (orientation:landscape)
		and (min-width: 319px) 
		and (max-width: 768px) {
			#Contact_Name_fieldNewForm,
			#Contact_Email_field,
			#Contact_Message_field{
				  margin-bottom: 10px !important;
			}
			.form-groupNewForm{
				margin-bottom: 10px !important;
				font-size: 13px !important;
			}
			.contact-submit-btn{
				    font-size: 15px;
			}
			.imageNewForm svg{
				width: 25px !important;
			}
			.form-controlNewForm{
				    padding: 4px !important;
			}
			.cardNew{
				padding-top: 2px;
			}
			#form_message{
				height: 58px;
			}
			.cardNew-title{
				    margin-bottom: 5px;
			}
			#creditNewForm{
				padding-bottom: 0;
    		max-width: min-content;
				max-height: -webkit-fill-available;
			}
		}

		@media screen  and (min-width: 319px) 
		and (max-width: 450px) {
			#creditNewForm{
				padding-top: 5px;
				padding-bottom: 0;
    		max-width: min-content;
				max-height: -webkit-fill-available;
				margin-bottom: inherit;
			}
			.cardNew-title{
				margin-bottom: 0.45rem;
			}
			.form-controlNewForm{
				padding: 0.175rem 0.75rem !important;
			}
			.form-groupNewForm{
				margin-bottom: 10px!important;
			}
			#form_fname-error,
			#form_email-error{
				font-size: smaller;
			}
		}*/


/*******************************************************************************************/

iframe {
    width: 75vw; 
	max-width: 698px;
    height: 42.19vw; 
	max-height: 390px;/* 100/56.25 = 560/315 = 1.778 */
    background:white;  
}




body    {margin:0;
	/*font-size: 1.05em;
	line-height: 1em;*/
	font-family: Tahoma, Geneva, sans-serif,Helvetica Neue, Helvetica, Arial;
	background: #ffcc33; /*MARGIN COLOR IMPORTANT IMPORTANT*/
	color: #555;
        
        
}

ul {
    
    list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
    position: fixed;
    top: 0;
    width: 100%;
    font-size:18px;
    line-height:20px;
                
}



li a {
    display: block;
    color: white;
    text-align: center;
    padding: 15px;
    text-decoration: none;
}

li a:hover:not(.active) {
    background-color: #111;
}

.active {
    background-color: #4CAF50;
}

.current {

	color: #2262AD;
}






/*<!-- /Nav Bar css/------------------------------------------------------->*/
#navbar {
  background-color: #333;
  position: fixed;
  top: 0;
  width: 100%;
  display: block;
  transition: top 0.3s;
}

#navbar a {
  float: center;   /*Was Right*/
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 15px;
  text-decoration: none;
  font-size: 17px;
}


/*-- /Nav Bar css/-->
<!-- /Nav Bar css/-->
<!-- /Nav Bar css/-->
<!-- /Nav Bar css/------------------------------------------------------->*/










/* Clearfix */
/* Clearfix */
/* Clearfix */
/* Clearfix */
.clearfix:before,
.clearfix:after {
    content: " ";
    display: table;
}
.clearfix:after {
    clear: both;
}
.clearfix {
    *zoom: 1;
}
.current {
	color: #111;
}
/*/ Clearfix /*/
/*/ Clearfix /*/
/*/ Clearfix /*/
/*/ Clearfix /*/










/*FONT*/	
/*FONT*/	
/*FONT*/	
/*FONT*/	
/*h1 font*/
h1 {

	font-size: 2em;
	color: #2262AD;
	line-height: 1.15em;
	margin: 5px 0 ;
}

/*p1 font*/
p1 {	
	font-size: 1.2em;
	line-height: 1em;
	margin: 7px 0 ;

}

@media only screen and (max-width : 900px) {
	
	
/*h1 font*/
h1 {

	font-size: 1.7em;
	color: #2262AD;
	line-height: 1.2em;
	margin: 7px 0 ;
}





}





@media only screen and (max-width : 800px) {
	
	
/*h1 font*/
h1 {

	font-size: 1.4em;
	color: #2262AD;
	line-height: 1.2em;
	margin: 9px 0 ;
}

/*p1 font*/

}



@media only screen and (max-width : 710px) {
/*h1 font*/
h1 {

	font-size: 1.2em;
	color: #2262AD;
	line-height: 1.2em;
	margin: 13px 0 ;
}

/*p1 font*/
p1 {	
	font-size: 1em;
	line-height: 1em;
	margin: 7px 0 ;

}

}


@media only screen and (max-width : 640px) {
	
	
/*h1 font*/
h1 {

	font-size: .9em;
	color: #2262AD;
	line-height: 1.2em;
	margin: 11px 0 ;
}

/*p1 font*/
p1 {	
	font-size: .8em;
	line-height: 1em;
	margin: 7px 0 ;

}

}
/*/FONT/*/	
/*/FONT/*/	
/*/FONT/*/	
/*/FONT/*/	









	
/*body div*/
/*body div*/
/*body div*/
/*body div*/
.container100 {
    width: 700px;
	
    margin: auto;
}


.container80 {
    width: 80%;
    max-width: 700px;
    margin: auto;
    border: 2px solid black;   /* black line around the whole web page to cut the page off from the bg */
    padding: 20px;

    /*did not exsist before in sales page*/
    height: auto;
    float: Center;
    background-color: white; /*BODY COLOR IMPORTANT IMPORTANT*/




}



.container40 {
    width: 60%;
	max-width: 600px;
    margin: auto;
}


.vercli
{ width:61%;
float: left;
}

.verpay
{ width:36%;
float: left;
}


/* float image left and lets text go around*/
.left  {
    float: Left;
    margin: 10 10 5px 5px;
	padding: 10px;
	max-width: 200px;
	width: 35%;
	height: auto;
} 

.right   {
  float: Right;
    margin: 10 10 5px 5px;
	padding: 10px;
	max-width: 200px;
	width: 35%;
	height: auto;
} 


.banner {  
width: 100%
}

.testimonial   {
  float: Center;
    margin: 20 20 10px 10px;
	padding: 0px;
	width: 90%;
	height: auto;

} 
.cards   {
  float: Center;
    margin: 00 00 00px 00px;
	padding: 0px;
	width: 40%;
	height: auto;
} 
.paypal   {
  float: Center;
    margin: 00 00 00px 00px;
	padding: 0px;
	width: 20%;
	height: auto;
} /*bod*/

.container   {
  float: Center;
    margin: 20 20 10px 10px;
	padding: 20px;
	width: 70%;
	height: auto;
background-color: lightblue;
alignment-adjust: middle;
} 
.container3   {
  float: Center;
    margin: 10 10 5px 5px;
	padding: 10px;
	width: 70%;
	height: auto;
background-color: white;
alignment-adjust: middle;
	border: 2px solid;
    border-top-left-radius: 2em;
    border-top-right-radius: 2em;
} 
.container4   {
  float: Center;
  display:
    margin: 10 10 5px 5px;
	padding: 10px;
	width: 70%;
	height: auto;
background-color: black;
alignment-adjust: middle;
	border: 2px solid;
    border-bottom-left-radius: 2em;
    border-bottom-right-radius: 2em;
} 
/*css to make text unsleectable*/
.unselectable {
  -webkit-user-select: none;  /* Chrome all / Safari all */
  -moz-user-select: none;     /* Firefox all */
  -ms-user-select: none;      /* IE 10+ */
  user-select: none;          /* Likely future */       
}
/*buy now box*/
#rcorners1 {
    border-radius: 25px;
    background: #000000;
    padding: 20px; 
    width: 70%;
	alignment-adjust: central;   
	height: autopx;    
}
div.google {
 	display:
	width: 20%;
	height: auto;
}

	/* diable right click*/
.body {
-webkit-user-select: none;  /* Chrome all / Safari all */
-moz-user-select: none;     /* Firefox all */
-ms-user-select: none;      /* IE 10+ */
-o-user-select: none;
user-select: none;
}

</style>
<!-- Nav Bar css end-->
<!-- Nav Bar css end-->
<!-- Nav Bar css end-->
<!-- Nav Bar css end-->




<!-- END SCRIPTS-->
<!-- END SCRIPTS-->
<!-- END SCRIPTS-->
<!-- END SCRIPTS-->




<script type="text/javascript" src="//script.crazyegg.com/pages/scripts/0017/2505.js" async="async"></script>

</head>



<!-- No Click BODY-->
<!-- No Click BODY-->
<!-- No Click BODY-->
<!-- No Click BODY-->
<body class="unselectable" body oncontextmenu="return false;"> 
<!-- No Click -->
<!-- No Click -->
<!-- No Click -->
<!-- No Click -->





<!--contact us code-->
<div class="cardNew" id="creditNewForm" style="display: none;">
		<div class="cardNew-title " id="contactUsTitle" >
				<div class="imageNewForm" >
					<svg fill="none" height="30" viewBox="0 0 24 24" width="30" xmlns="http://www.w3.org/2000/svg"><path d="M22 12C22 10.6868 21.7413 9.38647 21.2388 8.1731C20.7362 6.95996 19.9997 5.85742 19.0711 4.92896C18.1425 4.00024 17.0401 3.26367 15.8268 2.76123C14.6136 2.25854 13.3132 2 12 2V4C13.0506 4 14.0909 4.20703 15.0615 4.60889C16.0321 5.01099 16.914 5.60034 17.6569 6.34326C18.3997 7.08594 18.989 7.96802 19.391 8.93848C19.7931 9.90918 20 10.9495 20 12H22Z" fill="currentColor"/><path d="M2 10V5C2 4.44775 2.44772 4 3 4H8C8.55228 4 9 4.44775 9 5V9C9 9.55225 8.55228 10 8 10H6C6 14.4182 9.58173 18 14 18V16C14 15.4478 14.4477 15 15 15H19C19.5523 15 20 15.4478 20 16V21C20 21.5522 19.5523 22 19 22H14C7.37259 22 2 16.6274 2 10Z" fill="currentColor"/><path d="M17.5433 9.70386C17.8448 10.4319 18 11.2122 18 12H16.2C16.2 11.4485 16.0914 10.9023 15.8803 10.3928C15.6692 9.88306 15.3599 9.42017 14.9698 9.03027C14.5798 8.64014 14.1169 8.33081 13.6073 8.11963C13.0977 7.90869 12.5515 7.80005 12 7.80005V6C12.7879 6 13.5681 6.15527 14.2961 6.45679C15.024 6.7583 15.6855 7.2002 16.2426 7.75732C16.7998 8.31445 17.2418 8.97583 17.5433 9.70386Z" fill="currentColor"/></svg>
					<!-- <img src="contact-30.png" > -->
				</div>
	    	<div class="Text_headerNewForm" >	
	    		<div class="contact_us_headNewForm">Contact Us</div>
	    	</div>
	    	<div class="imageArrowNewForm">
					<span class="checkImageNewForm">
						<svg width="30px" id="chevronsArrowForm" class="chevron_downNewForm" onclick="chevronsArrowFormFunc(this)" viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg"><defs><style>.cls-1{fill:none;stroke:#fff;stroke-linecap:round;stroke-linejoin:round;stroke-width:2px;}</style></defs><title/><g id="chevron-bottom"><line class="cls-1" x1="16" x2="7" y1="20.5" y2="11.5"/><line class="cls-1" x1="25" x2="16" y1="11.5" y2="20.5"/></g></svg>
						<!-- <img src="chevron_downNewForm.png" width="8" > -->
					</span>
				</div>
		</div>
		<form id="creditNewForm_form" method="POST" name="creditNewForm_form" action="?" onsubmit="event.preventDefault();">
			<div class="form-rowNewForm" id="Contact_Name_fieldNewForm">
				<div class="form-groupNewForm">
					Name
					<input type="text" name="first_name" id="form_fname" class="form-controlNewForm error_message" >
					<!--- <span class="error_form" id="fname_error_message"></span> --->
				</div>
				<div class="form-groupNewForm" id="Contact_Email_field" >
					Email Address
					<input type="email" name="email" id="form_email" class="form-controlNewForm" type="email" >
					<!--- <span class="error_form" id="email_error_message"></span> --->
				</div>
				<div class="form-groupNewForm" id="Contact_Message_field" >
					Message
					<textarea class="form-controlNewForm" id="form_message" rows="3"></textarea>
					<!-- <input type="tex" name="password" id="form_password" class="form-controlNewForm" > -->
					<!--- <span class="error_form" id="password_error_message"></span> --->
				</div>

				<div class="form-groupNewForm text-center">
					<!-- <img src="image-name" width="300px" height="100px"> -->
					<button class="btn btn-primary contact-submit-btn" type="submit" >Send</button>
				</div>
			</div>
		</form>
</div>
<div class="contactOpenBtn">
	<img src="bubble.svg" width="100px" height="100px">
</div>


<!--contact us code-->




                      
<!--New Nav Bar-->
<!--New Nav Bar-->
<!--New Nav Bar-->
<!--New Nav Bar-->








</ul>
</div>
</nav>
<a href="https://penisprofessor.com/BuyNow.php">
<div id="navbar" align="left">
    <img class="" img src="https://penisprofessor.com/images/navbuy.jpg" width="120px" height="auto" border="0" name="submit" alt="ThePenisProfessor Join Today!" />
    </div>
</div></a>   

</div>


<!--New Nav Bar End-->
<!--New Nav Bar End-->
<!--New Nav Bar End-->
<!--New Nav Bar End-->










<!--Body in here-->
<!--Body in here-->
<!--Body in here-->
<!--Body in here-->
<div class="container80">
<!--Body in here-->
<!--Body in here-->
<!--Body in here-->
<!--Body in here-->










<!--Banner-->
<!--Banner-->
<!--Banner-->
<!--Banner-->
<h1 align="center" >

</h1>
<br />
<div align="center"><img class="banner" img src="images/banner.jpg" alt="Respond" /></div>
<!--Banner-->
<!--Banner-->
<!--Banner-->
<!--Banner-->




    <!--MembersLoging-->

    <!--MembersLoging-->

    <!--MembersLoging-->

    <!--MembersLoging-->

    <h3 align="right"><a href="https://verifiedmemberaccess.com/members.php" onMouseOut="MM_swapImgRestore()" onMouseOver="MM_swapImage('Image11','','members/images/memberloginroll.png',1)"><img src="https://www.thepenisprofessor.com/images/memberlogin.png" width="20%" height="auto" id="Image11"></a></h3>

    <!--end of MembersLoging-->

    <!--end of MembersLoging-->

    <!--end of MembersLoging--> 

    <!--end of MembersLoging-->







<!--H1-->
<!--H1-->
<!--H1-->
<!--H1-->
<h1 align="center" >
<br>
<font color="#dd0000"><br><u>RESULTS ARE GUARANTEED:</u></font>
<br>
<Font Color="#000000">ENLARGE YOUR PENIS  IN TWO MONTHS</font>
<br>
<font color="#dd0000"><u>OR YOUR MONEY BACK!</u></font>
</h1>
<!--H1-->
<!--H1-->
<!--H1-->
<!--H1-->










<!--P1-->
<!--P1-->
<!--P1-->
<!--P1-->    
<br />
  <div align="center"><p1><strong><font color="#000000">"The Only Effective Way To </font><br>
    <font color="#CC0000">ENLARGE YOUR PENIS 
  <br>
      1-4 Inches in 4 Weeks</font>
  <br>
  <font color="#000000">- Using ONLY Your Hands"</font></strong></p1></div>


<p>
</p>
<!--P1-->
<!--P1-->
<!--P1-->
<!--P1-->      
     





     
     
     
     
<!--H1 two-->
<!--H1 two-->
<!--H1 two-->
<!--H1 two-->
<h1 align="center"  >
<br>
<font color="#000000">Join today and access our NEW </font>
<br>
<font color="#cc0000">Mobile Friendly</font>
<font color="#000000"> members area with over</font>
<br>
<font color="#00CCCC">30 Different Penis Exercises!</font>
</h1>
<!--H1 two-->
<!--H1 two-->
<!--H1 two-->
<!--H1 two-->     










<!--Demo Vdieo-->     
<!--Demo Vdieo-->     
<!--Demo Vdieo-->     
<!--Demo Vdieo-->     
<p align="center"  >
<iframe src="https://player.vimeo.com/video/221955632" width="640" height="360" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
</p>
<!--/Demo Vdieo/-->     
<!--/Demo Vdieo/-->     
<!--/Demo Vdieo/-->     
<!--/Demo Vdieo/-->     










<!--English Only-->
<!--English Only-->
<!--English Only-->
<!--English Only-->
<p1 align="center"  >
  <div align="center"><br>
    <strong>Videos in <u>English Language Only</u>*</strong>
  <br>
  </div>
</p1>
<!--/English Only/-->
<!--/English Only/-->
<!--/English Only/-->
<!--/English Only/-->










<!--H1 three-->
<!--H1 three-->
<!--H1 three-->
<!--H1 three-->
<h1 align="center"  > 
<strong><font color="#cc0000">Increase Length &amp; Girth</font>
<br>
<font color="#000000"> - Improve Erection Hardness<br>
- <u>Boost Sexual Stamina</u>
<br>
and MORE!</font></strong>
</h1>
<!--/H1 three/-->
<!--/H1 three/-->
<!--/H1 three/-->
<!--/H1 three/-->










<!--HOW IT WORKS-->
<!--HOW IT WORKS-->
<!--HOW IT WORKS-->
<!--HOW IT WORKS-->
<br>
<br>
<h1 align="center">
<font style="BACKGROUND-COLOR: white">
 | How It Works | 
 </font>
</h1>











<!--HIW Image-->
<!--HIW Image-->
<!--HIW Image-->
<!--HIW Image-->
<div style="background-color: #FFF8C6; margin-left: 0px; 
margin-right: 0px; 
padding-bottom: 8px; 
padding-left: 8px; 
padding-right: 8px; 
padding-top: 8px;">
<img class="banner" src="images/thepenisprofessor.png" >



<p1 >
  <div align="justify">
    <p><font color="000000">Your penis is made up of three main veins or chambers. <br>
      <br>The two larger chambers run along the top of the penis and are called the Corpora Cavernosa. A third and smaller chamber called the Corpus Spongiosum, runs directly below the Corpora Cavernosa.
      <br>
      <br>
      Your erections size is limited by the amount of blood these chambers can hold. This is because your penis  uses blood pressure to become hard through basic hydraulics, and this is why your penis size is directly limited by the size of these three chambers.
      <br>
      <br>
      The secret to enlarging your penis, is to use exercises that naturally encourage more blood flow and increase the size of these 3 chambers allowing it to hold more blood. <strong>As your penis can hold more blood it will give your a bigger and bigger erection!</strong><br>
    </font></p>
  </div>
</p1>
</div> 
<!--HIW Image-->
<!--HIW Image-->
<!--HIW Image-->
<!--HIW Image-->










<div align="justify"><br>
  <br>
</div>
<p1>
  <div align="justify"><font color="#000000"> The Penis Professor does this by showing you with videos, how to use a modern blend of time tested penis enlargement techniques, modern medicine, and proven supplements. <br /></font>
    <br />
    <font color="#dd0000"><strong>The result is to greatly increase the amount of blood your penis can hold in these chambers, giving you a LONGER, THICKER, MORE SOLID ERECTION!</strong></font>
    <br>
    
    
    <br />
    <font color="#000000"><strong>The Penis Professors time tested techniques will greatly improve the size and strength of your erection, and your sexual performance in the bedroom...</strong></font> <font color="#dd0000"><strong>Not only are the gains you achieve with ThePenisProfessor permanent, but most grow twice as fast with our program over other methods!</strong></font></div>
</p1>
<div align="justify"><br />
  <br />
  
  
</div>
<div style="background-color: #FFF8C6; margin-left: 0px; 
margin-right: 0px; 
padding-bottom: 8px; 
padding-left: 8px; 
padding-right: 8px; 
padding-top: 8px;">
  <p1>
    <div align="justify">
      <p><font color="#000000"><strong>Currently The Penis Professor is the only site on the web that  only uses  safe, penis enlargement exercises and stretches  to Permanently Increase our Clients Penis Size. </strong><br />
          <br />
          <strong><em>PLUS - </em></strong>our Simple video instructions make learning easy, we will arm you with the Information and the know how to grow your penis quickly at home in privacy, and your personal trainer will always be polite and confidential. <strong>Best of all our approach Does Not Require Pills, Pumps</strong> or other expensive physical products!
          <br />
          <br />
        Join the thousands of men before you who have used out Video Lessons to learn these 32 magic  stretches and exercises, that will naturally increase your erection size in a safe and easy way <strong>millions of men have already used for centuries!</strong></font></p>
    </div>
  </p1>
</div>
<!--/HOW IT WORKS/-->
<!--/HOW IT WORKS/-->
<!--/HOW IT WORKS/-->
<!--/HOW IT WORKS/-->













<!--WHAT CAN THIS DO-->
<!--WHAT CAN THIS DO-->
<!--WHAT CAN THIS DO-->
<!--WHAT CAN THIS DO-->
<h1 align="center"  >
<br>
<br>
<br>


<FONT style="BACKGROUND-COLOR: white">
 | What Can Penis Exercises Do For Me? | </font></h1>
<p align="center"  >&nbsp;</p>
<!--/WHAT CAN THIS DO/-->
<!--/WHAT CAN THIS DO/-->
<!--/WHAT CAN THIS DO/-->
<!--/WHAT CAN THIS DO/-->






<!--WCTD Para1-->
<!--WCTD Para1-->
<!--WCTD Para1-->
<!--WCTD Para1-->
<p1 align="justify"  >
<font color="000"><strong>You will See Permanent Results</strong> - Other Methods will give you a temporary boost to penis size, and Surgery is both Risky and can cause Impotency, but The Penis Professor is SAFE AND EASY!
</font><p align="justify">
<!--/WCTD Para1/-->
<!--/WCTD Para1/-->
<!--/WCTD Para1/-->
<!--/WCTD Para1/-->





<!--WCTD image-->
<!--WCTD image-->
<!--WCTD image-->
<!--WCTD image-->
<img class="right" src="images/baredcss.jpg" >
<!--/WCTD image/-->
<!--/WCTD image/-->
<!--/WCTD image/-->
<!--/WCTD image/-->





<!--WCTD Para2-->
<!--WCTD Para2-->
<!--WCTD Para2-->
<!--WCTD Para2-->

<p align="justify"  >
<font color="000"><strong>You Will Grow a Longer Erection</strong> - If you follow our routine you will see an inch a month in length gain, First you will see Flaccid or Limp length gains, then erect. If at the end of a month you do not see this contact us and your Friendly and Professional Personal Trainer will help you!
<br />
<br />
<strong>You Will Grow a Thicker Penis</strong> - As you grow longer, you will also want to grow thicker, women all agree they love the feeling of being &quot;filled&quot;, just remember not to go too big so please plan ahead!</font>
<br />
<br />
<div style="background-color: #FFF8C6; margin-left: 0px; 
margin-right: 0px; 
padding-bottom: 8px; 
padding-left: 8px; 
padding-right: 8px; 
padding-top: 8px;">
  <div align="justify"><font color="000"><strong>You Can Correct Penis Twist and Curvature</strong>  - Our exercise Program will show you how to slowly with time, straighten and untwist your penis!
  <br />
  <br />
  <strong>You Can Enlarge Your Testicles</strong> - Learn how a once a day multi vitamin and a secondary zinc supplement can slowly increase testicle size!
  <br />
  <br />
  <strong>You Can End Impotence</strong> - We will show you how to get rock hard erections naturally, no pills, pumps, or needles!
  <br />
  <br />
    
  <strong>You Can End Premature Ejaculation</strong> - our</font><a href="https://penisprofessor.com/BonusContentdemo.php">
  <font color="#0000EE"><u>Bonus Guides</u></font></a><font color="000"> cover several books that teach you ways to  greatly increase how long you can have sex! Learn the secrets that will leave a woman sore, but wanting more which leads to her bringing a girl friend to you so &quot;they&quot; can keep up in bed with YOU!</font></div>
</div>
<div align="justify"><br />
  <br />
  <img class="left" src="images/bawhiteCSS.jpg" >
  <font color="000"><strong>You Will Gain Total Orgasm Control </strong>- our bonus guides also cover controlling when you cum and teaches you basics which will lead to you staying hard after your orgasm, leading to the ability to cum several times while staying erect!
  <br />
  <br />
  <strong>You Will Grow A Thicker Head</strong> - Many men don't understand how much joy and pleasure a Large Penis Head gives a women, but once your new penis it is inside her you will find she will get addicted to having sex with you!
  <br />
  <br />
  <strong>You Will See Noticeable Results</strong> - If your follow our exercise routine correctly, you will see flaccid or limp growth within two to three weeks, and erect growth a week or two later. Using our penis exercises you will quickly grow out to your current max length and in combination with our penis stretches grow further still! Remember to contact use so your Personal Trainer can help you with any issues after the first month. By then you should have seen a bit of growth and they will help you keep growing, or if you did not see as much as you wanted, they get you growing.</font></div>
</p1>
<div align="justify"><br>
  <br>
  <br>
</div>
 

<!--/WCTD Para2/-->
<!--/WCTD Para2/-->
<!--/WCTD Para2/-->
<!--/WCTD Para2/-->





<!--IS IT SAFE-->
<!--IS IT SAFE-->
<!--IS IT SAFE-->
<!--IS IT SAFE-->
<h1 align="center"  ><FONT style="BACKGROUND-COLOR: white">
 | Is It Safe? | </font></h1>
<br />

<!--/IS IT SAFE/-->
<!--/IS IT SAFE/-->
<!--/IS IT SAFE/-->
<!--/IS IT SAFE/-->
<br>
<!--IIS-->
<!--IIS-->
<!--IIS-->
<!--IIS-->
<div style="background-color: #FFF8C6; margin-left: 0px; 
margin-right: 0px; 
padding-bottom: 8px; 
padding-left: 8px; 
padding-right: 8px; 
padding-top: 8px;">
<p1 align="justify"  ><font color="#000000">Yes! So long as you follow our instructions  you will have no problems what so ever. Remember to Look at our section on trouble shooting before you start working out so you can know in advance what to look for, this will help you know in advance if your being to aggressive with your work outs.</font>
<br />
<br />
<strong><font color="#dd0000">Please take advantage of our HQ videos so you know how to do every penis exercise and stretch, we want you to know what to do so you grow fast in way that is Easy and Safe</font></strong>.</p1> </div>
<br>
<br>
<br>

<!--/IIS/-->
<!--/IIS/-->
<!--/IIS/-->
<!--/IIS/-->





<!--TESTIMONIALS-->
<!--TESTIMONIALS-->
<!--TESTIMONIALS-->
<!--TESTIMONIALS-->
<!--TESTIMONIALS-->
<!--TESTIMONIALS-->
<!--TESTIMONIALS-->
<!--TESTIMONIALS-->

<br />
<br />






<!--T7-->
<!--T7-->
<!--T7-->
<!--T7-->



<div id="wrapper" style="text-align:center">
  <div id="container" style="display:inline-block;text-align:left" class="container">
    <div align="center">
      <p align="left"  ><font color="#000000"
 face="Times New Roman, Times, serif" size="2">
          
          
          
          
      </font>          </div>
      <a href="https://penisprofessor.com/Testimonials.php"><h1 align="center"  ><FONT style="BACKGROUND-COLOR:white"><u>
  Want to see some Testimonials? </u></font></h1></a>

 <!--/T/7-->
<!--/T/7-->
<!--/T/7-->
<!--/T/7-->  

  </div>












<!--WHAT AM I GETTING HERE-->
<!--WHAT AM I GETTING HERE-->
<!--WHAT AM I GETTING HERE-->
<!--WHAT AM I GETTING HERE-->
 
<br />
<br />
<br />
<br />
<h1 align="center"  ><FONT style="BACKGROUND-COLOR: white">
 | What Am I Getting Here? | </font></h1>
<br />
<br />
</h1>
<!--/WHAT AM I GETTING HERE/-->
<!--/WHAT AM I GETTING HERE/-->
<!--/WHAT AM I GETTING HERE/-->
<!--/WHAT AM I GETTING HERE/-->
  
<!--WAIGH-->
<!--WAIGH-->
<!--WAIGH-->
<!--WAIGH-->
  <p1 align="center"  ><strong><font color="#cc0000">Over 30 High Quality<br>
<u>VIDEO LESSONS! </u></font></strong></p1>
<!--/WAIGH/-->
<!--/WAIGH/-->
<!--/WAIGH/-->
<!--/WAIGH/-->
 

<!--Sample Video-->
<!--Sample Video-->
<!--Sample Video-->
<!--Sample Video-->
 
        <p>
          <iframe src="https://player.vimeo.com/video/230889984" width="90%" height="auto" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
        </p>
<!--/Sample Video/-->
<!--/Sample Video/-->
<!--/Sample Video/-->
<!--/Sample Video/-->
        
        
<!--WAIGH-->
<!--WAIGH-->
<!--WAIGH-->
<!--WAIGH-->        
<p1 align="center"  >
<strong><font color="#cc0000">NOTICE:</font></strong> <font color="#000000">Our   High Definition Videos are Only in <u>English</u>.
<br />
<br />
<em>If you can watch this sample video, you can use the members area.</em></font>
<br />
<br />
Video List<br />
<strong>
<font color="#000000">
&bull;  5 Different Grip types to Maximum Growth!
</font> 
<br>
<font color="#000000">
&bull;</font>
<font color="#cc0000">  
Warming Up and Permanent Growth!
</font>
<br />
<font color="#000000">
&bull; 2 Testicle Enlargement Exercises!
</font>  
<br />
<font color="#000000">
&bull;</font>
<font color="#cc0000"> 
2 Advanced Length Exercises!
</font>
<br>  
<font color="#000000">
&bull; 10 Advanced Girth Exercises!
</font>
<br>   
<font color="#000000">
&bull;
</font>
<font color="#cc0000"> 
10 Basic Length Exercises!
</font>
<br />
<font color="#000000">
&bull; 4 Basic Girth Exercises!
</font>
</strong>
</p1>



<br />
<br />
<br />
<h1 align="center"  >
<font color="#cc0000"><em>PLUS!</em></font>
</h1>
<br />
<br />
<p1 align="center"  >
<font color="#000000"><b>You will get access to our </b></font> 
<br />
<strong><a href="BonusContentdemo.php"><font color="#0000CC"><u>Free Bonus Guides</u></font></a></strong>
</p1>

<p1 align="center"  >
<br /><br />
<font color="#000000"><strong>We will help you to 
<br />
<br />
- Reverse Impotence!
<br />
<br />
- Have Multiple Orgasms!
<br />
<br />
- End Premature Ejaculation!
<br />
<br />
- Learn 100 Sex Tips and Tricks!
<br />
<br />
- Gain access to Pre Made Work Outs!
<br />
<br />
- Correct Penile Twist and Curvature Issues!
<br />
<br />
<br />
- Get all of this and <em>MORE</em> while protected by an Internationally Backed</strong></font><br>
<font color="#cc0000"><u><strong>100% 8-week money back guarantee!</strong></u></font></p1>     
<br />
<br />
<br />    


<div style="background-color: #FFF8C6; margin-left: 0px; 
margin-right: 0px; 
padding-bottom: 8px; 
padding-left: 8px; 
padding-right: 8px; 
padding-top: 8px;">

<h1 align="center">
<font color="#000000">
<em>PLUS!</em>
</font>
</h1>
<p align="center">&nbsp;</p>    



<div>
<p1 align="center"><font color="black"> To Protect your Privacy with this  issue<br /> The Penis Professor is ONLY ONLINE!</font></p1>

<p1 align="justify">
  <p align="justify"><font color="#666666">Because All material is Digital, nothing will be sent in the mail! This way we can give you all future updates to the members area for FREE, and protect your privacy!</font></p>
</p1>



</div>

<br />
<br />
<div>
<p1 align="center"><font color="black"> Life time access with <br />No Re-occuring fee's!</font></p1>

<p1 align="justify">
  <p align="justify"><font color="#666666">The Penis Professor will never charge your credit card or bank account more than once. Our fee is a one-time fee and gives you lifetime access to our members area immediately after your purchase is complete.</font></p>
</p1>

</div>



<br />
<br />

<div>
<p1 align="center"><font color="black"> Unlimited online access <br />
    see everything your getting!</font></p1>

<p1 align="justify">
  <p align="justify"><font color="#666666">Members get lifetime access to all video lessons and bonus guides 100% free, including any future updates for new video lessons and bonus material.</font></p>
</p1>


</div>

<br />
<br />

<div>
<p1 align="center"><font color="black"> We are Secure and Discreet!</font></p1>

<p1 align="justify">
  <p align="justify"><font color="#666666">To protect you from possible prying eyes, the transaction will show as <!--&quot;PayPal*PProfessor&quot; for pay pall users, and -->WP-C2S.COM for credit cards and e-checks. We guarantee words like &quot;Penis&quot; will <i>never</i> appear on your bank account records. And by phone we Introduce our selves as &quot;DIGITAL SEA SUPPORT&quot; all done to protect you!</font></p>
</p1>
</div>







</div>


<!--/WAIGH/-->
<!--/WAIGH/-->
<!--/WAIGH/-->
<!--/WAIGH/-->

<br />
<br />
<!--Box Shot-->
<!--Box Shot-->
<!--Box Shot-->
<!--Box Shot-->
<img class="banner" img src="images/PenisProfessorBoxShot.jpg" alt="Respond" />
<!--/Box Shot/-->
<!--/Box Shot/-->
<!--/Box Shot/-->
<!--/Box Shot/-->







<!--White Box-->
<!--White Box-->
<!--White Box-->
<!--White Box-->
<br />
<br />
<br />
<div id="container" style="display:inline-block;text-align:left" class="container3">
<div align="center">
<h1 align="center"  >
<font color="#000099">Regular Price 
<span style="text-decoration: line-through;">$149.95</span></font>
</h1>
<h1 align="center"  >
<font color="#000099">Discount Price 
<span style="text-decoration: line-through;">$97</span></font>
</h1>
</div>
</div>
<!--/White Box/-->
<!--/White Box/-->
<!--/White Box/-->
<!--/White Box/-->

<!--Black Box-->
<!--Black Box-->
<!--Black Box-->
<!--Black Box-->
<div id="container" style="display:inline-block;text-align:left" class="container4">
<div align="center">
<h1 align="center"  >
<font color="#ffffff">SALE! Limited Time OFFER!</font>
<br />
<font color="#ff0000">ONLY 67 USD!</font>
</h1>
<p align="center" >
<font color="#ffffff">But Hurry, The Sale Ends Soon!</font>
</p>
      
      
      
    
</div>
</div>

<!--/Black Box/-->
<!--/Black Box/-->
<!--/Black Box/-->
<!--/Black Box/-->

<!--Want-->
<!--Want-->
<!--Want-->
<!--Want-->
<br />
<br />
<p1 align="center"  >
<br />
  <font color="#000000">
    <b>Don't You Want A Bigger Penis?
      <br>
      Lifetime Access, Updates, and Support!
      <br>
      Guaranteed Permanent Results!
      <br>
      Private and Discreet!
      <br>
      Safe and Easy!</b>
    <br>
  </font>
  <br />
  <br />
</p1>







<p1 align="center" ><font color="#000000">
  To Protect your Privacy, Paypal will bill you from <strong>"WP-C2S.com<!--PayPal*PProfessorPro"-->
</strong><br />
</font></p1>
<br />
  <br />
  


<h1 align="center"  ><FONT style="BACKGROUND-COLOR: white">
 | Your Order is 100% Safe |</font></h1>



<!--div align="center"><img class="container40" img src="images/trusted.png" alt="Respond" /></div-->
<!--/Want/-->
<!--/Want/-->
<!--/Want/-->
<!--/Want/-->




<!--Buy-->
<!--Buy-->
<!--Buy-->
<!--Buy-->
<div align="center">



<div id="rcorners1" class="div.ex5">
       
    <p1 align="center" ><font color="#ffffff">ORDER NOW WITH CLICK2SELL SECURE SERVERS<br>
INSTANT ACCESS - FULLY SECURE<br>
MONEY BACK GUARANTEE
</font>
<br>


<img class="cards" src="images/cards.jpg" alt="responcive"><br>






<img class="paypal" src="images/paypal.jpg" alt="responcive">











    <p>&nbsp; </p>
    <a href="BuyNow.php"><img src="images/WEACCEPTECREDIT.jpg" style='width:70%;' border="0" alt="Null"/></a>          
    <a href="BuyNow.php"><img src="images/WEACCEPTECHECKS.jpg" style='width:70%;' border="0" alt="Null"/></a>
    <a href="BuyNow.php"><img src="images/WEACCEPTPAYPAL.jpg" style='width:70%;' border="0" alt="Null"/></a>
          <p>&nbsp; </p>
                                      
                                       
                                          
                                          
                                          
    </p1>
    
</div>
</div>
<p1>
  <p><strong><font color="#FF0000">WARNING: This Program Is Only For Men Who Need A Bigger Penis
  <br>
    Results Are Permanent And Cannot Be Reversed!</font></strong></p>
  <p>&nbsp;</p>
</p1>
<p align="left"><a href="https://www.paypal.com/us/verified/pal=digitalseasupport%40hotmail%2ecom" target="_blank"><img src="https://www.paypal.com/en_US/i/icon/verification_seal.gif" border="0" alt="Official PayPal Seal" style="margin: 0pt 10px 0pt 0pt; float: left;" /></a></p>
  <p1>
    <div align="left">You have 3rd Party Protection to Back your <br>
      <font color="#cc0000">
        <strong>
        8-week "No Questions" refund guarantee
        </strong>
        </font>
    </div>
  </p1> 

 
 
 
  <div align="left"><a href="BuyNow.php"><img src="images/orderword.jpg" width="232" height="19" border="0" alt="Join thepenisprofessor today"/></a></div>
  <p1 align="left"  >
    <div align="left"><font color="#000000">
    <br />
  
    <strong>Start Growing Today, </strong>for </font><font color="#cc0000"><strong>just 67 USD </strong></font><font color="#000000"><br />
      don't pay the full price of $149 </font>
    <br>
    <br>
  </div>
</p1>
<p1 align="left"  >
<font color="#000000"><strong>Get the Help you Need! </strong>Our friendly and professional staff are here to help, so contact us when ever you need.</font></p1>


<p1 align="center"  >
<br />
<br />
<br />
</p1>
<!--/Buy/-->
<!--/Buy/-->
<!--/Buy/-->
<!--/Buy/-->
  
  
<!-- Start of StatCounter Code for Dreamweaver -->
<!-- Start of StatCounter Code for Dreamweaver -->
<!-- Start of StatCounter Code for Dreamweaver -->
<!-- Start of StatCounter Code for Dreamweaver -->
<script type="text/javascript">
var sc_project=11008266; 
var sc_invisible=1; 
var sc_security="04456386"; 
var scJsHost = (("https:" == document.location.protocol) ?
"https://secure." : "http://www.");
document.write("<sc"+"ript type='text/javascript' src='" +
scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript></noscript>
<!-- /End of StatCounter Code for Dreamweaver/ -->
<!-- /End of StatCounter Code for Dreamweaver/ -->
<!-- /End of StatCounter Code for Dreamweaver/ -->
<!-- /End of StatCounter Code for Dreamweaver/ -->



</div>
</div>
<br />
<br />
<p align="center">
<a href="https://penisprofessor.com/index.php">Home</a> | <a href="https://verifiedmemberaccess.com/members.php">Member Login</a> </p> 
<div align="center">Copyright PenisProfessor.com <br>All Rights Reserved &copy; 2012 - 2026



<br />
<br />
<br />
<br />
</div>

</div>

</body>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js" ></script>
<script src="https://smtpjs.com/v3/smtp.js"></script> 
<script type="text/javascript">
	
$.validator.addMethod("lettersonly", function(value, element) {
    return this.optional(element) || /^[a-zA-Z\s ]*$/.test(value);
}, "Should contain only characters.");
$.validator.addMethod("numeric", function(value, element) {
    return this.optional(element) || /^[0-9]*$/.test(value);
}, "Should contain only numbers.");
$.validator.addMethod("email", function(value, element) {
    return this.optional(element) || /^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\.[a-zA-Z.]{2,5}$/i.test(value);
}, "Please enter a valid email address.");
$.validator.addMethod("minimum_ammount", function(value, element) {
    return this.optional(element) || /^[5-9]*$/.test(value);
},);
var submitForm = 0;

$('#creditNewForm_form').validate({  
  rules:{
    first_name:{
      required:true,
      lettersonly: true
    },
    email:{
      required:true,
      email:true
    },
  },
  messages:{
    first_name:{
      required:"Please enter your name",
    },
    email:{
      required:"Please enter email",
    },

  },

    submitHandler:function(form){
    	console.log('submitform');
    	submitForm = 1;
    	contact_submit(submitForm);
    }
});
$(".contactOpenBtn").on('click',function(){
		$("#creditNewForm").fadeIn(200);
		$(".contactOpenBtn").fadeOut(200);
});
function chevronsArrowFormFunc(key){
	var image_name = $(key).attr('class');
	if (image_name == 'chevron_downNewForm') {
		$(".contactOpenBtn").fadeIn(250);
		$("#creditNewForm").fadeOut(250);
	}
}
function contact_submit(submitForm){
	if(submitForm == 1){
		console.log('esle');
		var send = false;
		var getname = $("#creditNewForm_form #form_fname").val();
		var getemail = $("#creditNewForm_form #form_email").val();
		var getmessage = $("#creditNewForm_form #form_message").val();
		if (getmessage.trim() == '') {
			getmessage = 'Empty';
		}

		var myFormData = new FormData();

  	myFormData.append("name", getname);
  	myFormData.append("email", getemail);
  	myFormData.append("message", getmessage);

		$.ajax({
			url: "faq_ajax.php",
			type: "post",
			data:myFormData,
			success: function (data) {
				$("#creditNewForm_form").trigger('reset');
				$(".contactOpenBtn").fadeIn(250);
				$("#creditNewForm").fadeOut(250);
      },
			cache: false,
      contentType: false,
      processData: false,
		});
	}
}
</script>





<script>
var prevScrollpos = window.pageYOffset;
window.onscroll = function() {
var currentScrollPos = window.pageYOffset;
  if (prevScrollpos > currentScrollPos) {
    document.getElementById("navbar").style.top = "0";
  } else {
    document.getElementById("navbar").style.top = "-50px";
  }
  prevScrollpos = currentScrollPos;
}
</script>


</html>
